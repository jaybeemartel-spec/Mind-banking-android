plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mindbanking.demo"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mindbanking.demo"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.3.0"
    }
}
